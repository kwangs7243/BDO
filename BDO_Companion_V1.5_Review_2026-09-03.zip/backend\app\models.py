from __future__ import annotations

from datetime import date, datetime, time

from sqlalchemy import Boolean, Date, DateTime, ForeignKey, Integer, String, Text, Time, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


class Source(Base):
    __tablename__ = "source"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    url: Mapped[str] = mapped_column(Text, nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    publisher: Mapped[str | None] = mapped_column(String(120))
    source_type: Mapped[str] = mapped_column(String(32), nullable=False)
    published_at: Mapped[date | None] = mapped_column(Date)
    retrieved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    region: Mapped[str] = mapped_column(String(16), default="KR", nullable=False)


class Content(Base):
    __tablename__ = "content"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    slug: Mapped[str] = mapped_column(String(120), unique=True, nullable=False)
    name_ko: Mapped[str] = mapped_column(String(255), nullable=False)
    category: Mapped[str] = mapped_column(String(64), nullable=False)
    subcategory: Mapped[str | None] = mapped_column(String(64))
    summary: Mapped[str | None] = mapped_column(Text)
    purpose: Mapped[str | None] = mapped_column(Text)
    party_type: Mapped[str | None] = mapped_column(String(32))
    difficulty: Mapped[str | None] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(32), default="active", nullable=False)
    last_verified_at: Mapped[date | None] = mapped_column(Date)

    schedules: Mapped[list[ScheduleRule]] = relationship(back_populates="content", cascade="all, delete-orphan")
    checklist_templates: Mapped[list[ChecklistTemplate]] = relationship(
        back_populates="content", cascade="all, delete-orphan"
    )


class ScheduleRule(Base):
    __tablename__ = "schedule_rule"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    content_id: Mapped[int] = mapped_column(ForeignKey("content.id"), nullable=False)
    rule_type: Mapped[str] = mapped_column(String(32), nullable=False)
    timezone: Mapped[str] = mapped_column(String(64), default="Asia/Seoul", nullable=False)
    recurrence_type: Mapped[str] = mapped_column(String(32), nullable=False)
    weekday: Mapped[int | None] = mapped_column(Integer)
    time_local: Mapped[time | None] = mapped_column(Time)
    effective_from: Mapped[date | None] = mapped_column(Date)
    effective_to: Mapped[date | None] = mapped_column(Date)
    notes: Mapped[str | None] = mapped_column(Text)

    content: Mapped[Content] = relationship(back_populates="schedules")


class Evidence(Base):
    __tablename__ = "evidence"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    entity_type: Mapped[str] = mapped_column(String(32), nullable=False)
    entity_id: Mapped[str] = mapped_column(String(128), nullable=False)
    claim_key: Mapped[str] = mapped_column(String(128), nullable=False)
    source_id: Mapped[str] = mapped_column(ForeignKey("source.id"), nullable=False)
    evidence_note: Mapped[str | None] = mapped_column(Text)
    verification_status: Mapped[str] = mapped_column(String(32), nullable=False)
    last_verified_at: Mapped[date] = mapped_column(Date, nullable=False)
    superseded_by: Mapped[int | None] = mapped_column(ForeignKey("evidence.id"))

    source: Mapped[Source] = relationship(foreign_keys=[source_id])


class ChecklistTemplate(Base):
    __tablename__ = "checklist_template"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    content_id: Mapped[int | None] = mapped_column(ForeignKey("content.id"))
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    recurrence_scope: Mapped[str] = mapped_column(String(32), nullable=False)
    enabled_default: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    content: Mapped[Content | None] = relationship(back_populates="checklist_templates")
    items: Mapped[list[ChecklistTemplateItem]] = relationship(
        back_populates="template", cascade="all, delete-orphan", order_by="ChecklistTemplateItem.order_no"
    )
    instances: Mapped[list[ChecklistInstance]] = relationship(back_populates="template")


class ChecklistTemplateItem(Base):
    __tablename__ = "checklist_template_item"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    template_id: Mapped[int] = mapped_column(ForeignKey("checklist_template.id"), nullable=False)
    order_no: Mapped[int] = mapped_column(Integer, nullable=False)
    label: Mapped[str] = mapped_column(String(255), nullable=False)
    details: Mapped[str | None] = mapped_column(Text)
    reward_hint: Mapped[str | None] = mapped_column(Text)

    template: Mapped[ChecklistTemplate] = relationship(back_populates="items")


class ChecklistInstance(Base):
    __tablename__ = "checklist_instance"
    __table_args__ = (UniqueConstraint("template_id", "period_key", name="uq_checklist_period"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    template_id: Mapped[int] = mapped_column(ForeignKey("checklist_template.id"), nullable=False)
    period_key: Mapped[str] = mapped_column(String(100), nullable=False)
    period_start: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    period_end: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    generated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)

    template: Mapped[ChecklistTemplate] = relationship(back_populates="instances")
    states: Mapped[list[ChecklistItemState]] = relationship(
        back_populates="instance", cascade="all, delete-orphan"
    )


class ChecklistItemState(Base):
    __tablename__ = "checklist_item_state"
    __table_args__ = (UniqueConstraint("instance_id", "template_item_id", name="uq_checklist_item_state"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    instance_id: Mapped[int] = mapped_column(ForeignKey("checklist_instance.id"), nullable=False)
    template_item_id: Mapped[int] = mapped_column(ForeignKey("checklist_template_item.id"), nullable=False)
    completed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    note: Mapped[str | None] = mapped_column(Text)

    instance: Mapped[ChecklistInstance] = relationship(back_populates="states")
    template_item: Mapped[ChecklistTemplateItem] = relationship()

