from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo


KST = ZoneInfo("Asia/Seoul")
THURSDAY = 3
SUNDAY = 6


@dataclass(frozen=True)
class Period:
    key: str
    start: datetime
    end: datetime


def ensure_kst(now: datetime) -> datetime:
    if now.tzinfo is None:
        raise ValueError("now must be timezone-aware")
    return now.astimezone(KST)


def daily_period(now: datetime) -> Period:
    local = ensure_kst(now)
    start = datetime.combine(local.date(), time.min, tzinfo=KST)
    return Period(f"D:{start.date().isoformat()}", start, start + timedelta(days=1))


def weekly_period(now: datetime, weekday: int = THURSDAY) -> Period:
    local = ensure_kst(now)
    start_date = local.date() - timedelta(days=(local.weekday() - weekday) % 7)
    start = datetime.combine(start_date, time.min, tzinfo=KST)
    return Period(f"W:{start.isoformat()}", start, start + timedelta(days=7))


def next_weekly_occurrence(now: datetime, weekday: int, at: time = time.min) -> datetime:
    """Return the next schedule occurrence, treating an exact boundary as current."""

    local = ensure_kst(now)
    candidate_date: date = local.date() + timedelta(days=(weekday - local.weekday()) % 7)
    candidate = datetime.combine(candidate_date, at, tzinfo=KST)
    if candidate < local:
        candidate += timedelta(days=7)
    return candidate

