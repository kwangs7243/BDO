# BDO Companion V1.5 — Project Snapshot

- Snapshot date: 2026-09-03 (Asia/Seoul)
- Purpose: 다음 콘텐츠 대량 확장 단계의 설계 및 외부 검수
- Scope: 현재 구현된 V1.5 vertical slice
- Runtime AI boundary: LLM/API 호출 없음, API key 설정 없음

이 문서는 ZIP에 포함된 코드의 현재 상태를 설명한다. 아직 구현되지 않은 기능을 완료된 것으로 간주하지 않는다. 실제 SQLite DB, `.env`, `node_modules`, 가상환경, 빌드 결과와 캐시는 패키지에서 제외했다.

## 1. 현재 디렉터리 구조

```text
BDO_Companion_V1.5_Review_2026-09-03/
├─ AGENTS.md
├─ ARCHITECTURE.md
├─ README.md
├─ .gitignore
├─ backend/
│  ├─ app/
│  │  ├─ main.py                 # FastAPI 진입점과 endpoint
│  │  ├─ models.py               # SQLAlchemy 모델
│  │  ├─ schemas.py              # API/Prompt Pydantic 계약
│  │  ├─ database.py             # engine/session/schema 초기화
│  │  ├─ config.py               # DATABASE_URL과 seed 경로
│  │  ├─ content.py              # 콘텐츠/근거 조회
│  │  ├─ checklists.py           # period instance 조회·생성
│  │  ├─ periods.py              # KST 기간/일정 계산
│  │  ├─ prompt_bridge.py        # context 수집과 Markdown 렌더링
│  │  └─ seed.py                 # 멱등 seed importer
│  ├─ alembic/
│  │  ├─ env.py
│  │  ├─ script.py.mako
│  │  └─ versions/20260902_0001_initial.py
│  ├─ tests/
│  ├─ alembic.ini
│  ├─ pyproject.toml
│  ├─ uv.lock
│  └─ .env.example               # 패키지용 SQLite 기본 설정 예시
├─ frontend/
│  ├─ src/
│  │  ├─ components/
│  │  ├─ features/
│  │  │  ├─ content/
│  │  │  ├─ dashboard/
│  │  │  ├─ weekly/
│  │  │  └─ prompt-bridge/
│  │  ├─ api.ts
│  │  ├─ types.ts
│  │  ├─ App.tsx
│  │  └─ main.tsx
│  ├─ package.json
│  ├─ package-lock.json
│  ├─ index.html
│  └─ Vite/TypeScript/Vitest/ESLint 설정
├─ data/
│  ├─ seed_contents.json
│  └─ seed_sources.json
├─ db/schema.sql                # 초기 참고 스키마
├─ docs/                        # 제품·데이터·UI·Prompt Bridge 정본
├─ prompts/                     # 구현/연구 작업용 프롬프트
└─ handoff/PROJECT_SNAPSHOT.md
```

DB 구조를 검수할 때는 `backend/app/models.py`와 Alembic migration을 현재 구현의 기준으로 사용한다. `db/schema.sql`은 프로젝트 초기에 작성된 참고 스키마이므로 일부 구현 필드와 차이가 있을 수 있다.

## 2. 구현된 화면 목록과 역할

| 경로 | 화면 | 역할 |
|---|---|---|
| `/` | Dashboard | 일일·목요일 주간·일요일 보상 지급 경계와 이번 주 체크 일부를 표시한다. |
| `/weekly` | Weekly | 목요일 00:00 KST period의 체크리스트 전체, 완료 수, 일요일 보상 일정 분리 안내를 표시한다. 체크 상태를 저장할 수 있다. |
| `/content` | Content Explorer | seed 콘텐츠를 이름/설명과 카테고리로 필터링하고 검증 상태·검증일을 표시한다. |
| `/content/:slug` | Content Detail | 요약, 목적(데이터가 있을 때), 일정, source/evidence, 검증 상태를 표시하고 `content_onboarding` Prompt Bridge를 연다. |
| `/prompt` | Prompt Bridge | 콘텐츠 입문 또는 주간 검토 prompt 생성 진입점을 제공한다. |

전역 UI는 React Router를 사용한다. `/today`, `/life`, `/projects`, `/sources`, `/settings` 등 정본 UI map의 나머지 화면은 아직 구현되지 않았다.

## 3. API endpoint 목록

| Method | Endpoint | 역할/주요 입력 |
|---|---|---|
| `GET` | `/api/health` | 서버 상태, KST 기준, LLM transport 비활성 상태를 반환한다. |
| `GET` | `/api/contents` | 콘텐츠 목록과 집계된 검증 상태를 반환한다. |
| `GET` | `/api/contents/{slug}` | 콘텐츠 상세, schedules, evidence/source를 반환한다. |
| `GET` | `/api/checklists/current?scope=daily|weekly` | 현재 period의 instance를 조회하며 없으면 생성한다. |
| `PATCH` | `/api/checklists/states/{state_id}` | `completed`, `note`를 저장하고 완료 시간을 관리한다. |
| `GET` | `/api/dashboard` | 현재 reset/deadline 그룹과 daily/weekly 체크리스트를 반환한다. |
| `POST` | `/api/prompt/context` | `mode`, timezone-aware `as_of`, 선택적 `content_slug`, 질문으로 `PromptContextBundle`을 만든다. |
| `POST` | `/api/prompt/render` | 같은 입력으로 bundle과 결정론적 Markdown, 문자 수, token 추정치, 크기 경고를 반환한다. |

Prompt endpoint에서 현재 지원하는 `mode`는 `content_onboarding`, `weekly_review`뿐이다.

## 4. 주요 DB 테이블과 관계

| 테이블 | 목적 | 주요 관계 |
|---|---|---|
| `source` | 공식 가이드/패치 등 출처 원장 | `evidence.source_id`가 참조 |
| `content` | 콘텐츠 지식의 중심 엔티티 | schedules와 checklist templates를 1:N으로 소유 |
| `schedule_rule` | 재수주, 횟수 초기화, 보상 지급 등 서로 다른 시계를 분리 | `content_id → content.id` |
| `evidence` | claim 단위 출처, 검증 상태, 검증일 | `source_id → source.id`, 선택적 `superseded_by → evidence.id` |
| `checklist_template` | 반복 체크리스트 정의 | 선택적 `content_id → content.id` |
| `checklist_template_item` | template의 순서 있는 항목 | `template_id → checklist_template.id` |
| `checklist_instance` | 특정 period에 생성된 template 인스턴스 | `(template_id, period_key)` unique, 과거 period 보존 |
| `checklist_item_state` | 특정 instance 항목의 완료·메모 상태 | `(instance_id, template_item_id)` unique |

현재 DB에는 project/material, user content state, content requirements/steps/rewards 모델이 없다. 문서의 장기 데이터 모델 전체가 구현된 상태는 아니다.

## 5. seed로 들어간 검은사막 콘텐츠 목록

| slug | 콘텐츠 | 구조화된 일정 | checklist |
|---|---|---|---|
| `weekly-quest-framework` | 주간 의뢰 공통 규칙 | 목요일 00:00 `quest_reset` | 있음 |
| `blood-altar` | 피의 제단 | 일요일 00:00 `reward_payout` | 있음 |
| `pit-of-undying` | 불멸의 나락 | 없음 | 있음 |
| `garmoth` | 가모스 | 목요일 00:00 `attempt_reset` | 있음 |
| `vell` | 벨 | 없음 | 없음 |
| `life-common-gear` | 생활 통합 장비 | 없음 | 없음 |
| `carrack-advance` | 에페리아 중범선 : 점진 | 없음 | 없음 |

총 7개 콘텐츠와 15개 source registry 항목이 있다. 각 콘텐츠 seed는 현재 summary, status, last verified date와 source 연결 중심이다. importer는 각 연결을 `summary` claim의 evidence로 만든다.

## 6. 현재 체크리스트/주기 엔진 구조

- 기준 timezone은 `Asia/Seoul`이다.
- daily key: `D:YYYY-MM-DD`.
- Thursday weekly key: `W:<목요일 00:00+09:00 ISO datetime>`.
- 일요일 00:00 보상 지급은 checklist reset이 아니라 별도 weekly occurrence로 계산한다.
- 현재 period를 조회할 때 `(template_id, period_key)` instance가 없으면 생성하고, 있으면 재사용한다.
- 새 period에서는 새 instance/state를 생성하며 이전 instance와 완료 기록을 UPDATE로 초기화하거나 삭제하지 않는다.
- 동시 조회는 unique constraint와 `IntegrityError` 처리로 같은 period instance를 재사용한다.
- 현재 UI/seed에는 weekly checklist만 있으며 daily template 데이터는 없다.
- 커스텀 RRULE/fixed datetime/manual period 계산은 모델/정본에는 있으나 엔진에 아직 구현되지 않았다.

## 7. Prompt Bridge 현재 구현 범위

구현됨:

- `PromptMode`: `content_onboarding`, `weekly_review`.
- `PromptContextBundle`과 고정된 Markdown 섹션 순서.
- 콘텐츠 summary, schedule, 현재 checklist, evidence/source 수집.
- `verified` fact와 `needs_review`/`conflict`/그 밖의 미해결 fact 분리.
- source title, URL, type, last verified date 직렬화.
- 동일한 명시적 `as_of`와 DB 상태에서 안정적인 출력 정렬.
- 기본 guardrail, 사용자 질문 결합, 문자 수와 약식 token 추정, 12,000 token 초과 표시.
- Content Detail, Weekly, 전역 Prompt 화면 진입점.
- 미리보기, clipboard 복사, 실패 시 textarea 선택, Markdown 다운로드.
- 백엔드 생성 과정에서 outbound network를 시도하지 않는 테스트.

미구현:

- `next_action`, `project_optimizer`, `verify_latest` preset.
- context section 토글과 context-only/full-prompt 전환.
- 12,000 token 초과 시 실제 truncation/budgeting 정책.
- user state 및 project state collector. Bundle 필드는 존재하지만 현재 비어 있다.
- life/project detail 진입점.
- Prompt 생성 결과 저장과 외부 자동 전송은 V1.5 의도상 구현하지 않는다.

## 8. 아직 stub이거나 데이터가 부족한 부분

- Project/material: 테이블, 부족량 계산, Carrack 재료, 단계 DAG, `project_optimizer`가 없다. ADR-007에 따라 빈 stub도 만들지 않았다.
- Knowledge detail: requirements, steps, rewards, related contents, 사용자 상태/메모가 없다.
- Seed coverage: 7개 모두 상세 페이지를 채우기에는 부족하다. 벨·생활 통합 장비·중범선 점진은 summary/source 수준이다.
- Evidence granularity: 현재 importer는 source 연결을 summary claim evidence로 만든다. schedule 등 개별 핵심 claim별 evidence 연결은 다음 확장 전에 설계가 필요하다.
- Recurrence: daily/Thursday weekly와 weekly occurrence만 계산한다. event end, spawn, custom period/RRULE은 미구현이다.
- User data: `user_content_state`, export/import, 캐릭터·생활 상태가 없다.
- Search: Content Explorer의 클라이언트 필터만 있고 통합 검색 API/색인이 없다.
- Source operations: conflict 관리/연구 import UI가 없다.
- Frontend automated coverage: 현재 status badge 단위 테스트 1개뿐이며 화면/API 상호작용 테스트가 부족하다.

## 9. 다음 milestone에서 데이터를 확장할 때 건드려야 할 주요 파일

| 목적 | 주요 파일 |
|---|---|
| 검증된 콘텐츠/source 추가 | `data/seed_contents.json`, `data/seed_sources.json` |
| seed 포맷과 evidence 생성 확장 | `backend/app/seed.py` |
| 새 DB 엔티티/관계 | `backend/app/models.py`, `backend/alembic/versions/<new_revision>.py` |
| API 응답 계약 | `backend/app/schemas.py` |
| 콘텐츠 조회와 검증 집계 | `backend/app/content.py` |
| reset/custom schedule 계산 | `backend/app/periods.py`, `backend/app/checklists.py` |
| Prompt collector/preset 확장 | `backend/app/prompt_bridge.py`, `backend/app/schemas.py` |
| API endpoint 추가 | `backend/app/main.py` |
| 화면/route 추가 | `frontend/src/App.tsx`, `frontend/src/features/` |
| 프런트 API 계약 | `frontend/src/api.ts`, `frontend/src/types.ts` |
| 경계·history·source·Prompt 회귀 테스트 | `backend/tests/`, `frontend/src/**/*.test.tsx` |
| 정본/구현 상태 동기화 | `docs/specs/001-core/`, `docs/specs/002-prompt-bridge/`, `docs/DECISIONS.md`, `README.md` |

대량 콘텐츠 입력 전에는 claim별 source/evidence 입력 포맷과 schedule/checklist seed schema를 먼저 안정화하는 것이 핵심 검수 포인트다. 공식 근거가 없는 게임 수치나 reset 규칙은 확정 데이터로 추가하지 않는다.

## 10. 현재 테스트 결과

2026-09-03 Asia/Seoul 기준:

| 검증 | 결과 |
|---|---|
| `cd backend; uv run pytest` | 16 passed |
| `cd frontend; npm run typecheck` | 통과 |
| `cd frontend; npm run lint` | 통과 |
| `cd frontend; npm run test` | 1 passed |
| `cd frontend; npm run build` | 통과(직전 구현 검증) |

백엔드 테스트는 KST 일일/목요일 주간 경계, 월·연도 경계, 일요일 보상 경계 분리, checklist history 보존, source 검증 상태 노출, seed 멱등성, Prompt 결정성, 완료/미완료 상태 반영과 no-network invariant를 포함한다.

실제 SQLite migration/seed/server 부팅과 상태 재조회는 구현 완료 시 검증했다. MySQL은 offline DDL 생성까지만 확인했으며 실제 MySQL 서버 연결 테스트는 수행하지 않았다.

