from __future__ import annotations

from datetime import date, datetime
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, field_validator


class SourceOut(BaseModel):
    id: str
    title: str
    url: str
    source_type: str
    verification_status: str
    last_verified_at: date
    evidence_note: str | None = None


class ScheduleOut(BaseModel):
    id: int
    rule_type: str
    recurrence_type: str
    weekday: int | None
    time_local: str | None
    timezone: str
    notes: str | None
    next_occurrence: datetime | None = None


class ContentSummaryOut(BaseModel):
    slug: str
    name_ko: str
    category: str
    summary: str | None
    status: str
    last_verified_at: date | None
    verification_status: str


class ContentDetailOut(ContentSummaryOut):
    purpose: str | None
    party_type: str | None
    difficulty: str | None
    schedules: list[ScheduleOut]
    sources: list[SourceOut]


class ChecklistStateOut(BaseModel):
    id: int
    template_item_id: int
    label: str
    details: str | None
    completed: bool
    completed_at: datetime | None
    note: str | None


class ChecklistInstanceOut(BaseModel):
    id: int
    template_id: int
    template_name: str
    content_slug: str | None
    period_key: str
    period_start: datetime
    period_end: datetime
    items: list[ChecklistStateOut]


class ChecklistStateUpdate(BaseModel):
    completed: bool
    note: str | None = None


class PromptMode(StrEnum):
    CONTENT_ONBOARDING = "content_onboarding"
    WEEKLY_REVIEW = "weekly_review"


class PromptRequest(BaseModel):
    mode: PromptMode
    content_slug: str | None = None
    user_question: str = ""
    as_of: datetime

    @field_validator("as_of")
    @classmethod
    def require_timezone(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError("as_of must be timezone-aware")
        return value


class PromptFact(BaseModel):
    claim: str
    verification_status: str
    last_verified_at: date | None = None
    source_title: str | None = None
    source_url: str | None = None
    source_type: str | None = None


class PromptChecklistItem(BaseModel):
    label: str
    completed: bool
    period_key: str


class PromptContextBundle(BaseModel):
    model_config = ConfigDict(use_enum_values=True)

    generated_at: datetime
    region: str = "KR"
    request_context: dict[str, str]
    user_state: list[str] = Field(default_factory=list)
    canonical_facts: list[PromptFact] = Field(default_factory=list)
    schedules: list[str] = Field(default_factory=list)
    checklist: list[PromptChecklistItem] = Field(default_factory=list)
    project_state: list[str] = Field(default_factory=list)
    open_questions_or_conflicts: list[PromptFact] = Field(default_factory=list)
    sources: list[SourceOut] = Field(default_factory=list)
    user_question: str = ""


class PromptRenderOut(BaseModel):
    bundle: PromptContextBundle
    markdown: str
    character_count: int
    estimated_tokens: int
    over_budget: bool
