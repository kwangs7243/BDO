# BDO Companion — 검은사막 개인 운영체제

목표: 단순 숙제 체크리스트가 아니라, **검은사막 콘텐츠 위키 + 진행도 + 반복 숙제 + 프로젝트/재료 트래커 + 근거 관리**를 하나로 묶는 로컬 웹앱.

## 핵심 사용 시나리오

1. "수렵 한번 해볼까?" → 수렵 페이지 진입 → 왜 하는지 / 준비물 / 장비 / 시작 루트 / 체크리스트 / 추천 다음 단계 확인.
2. "이번 주 뭐 안 했지?" → 주간 대시보드 → 초기화 규칙별로 남은 콘텐츠 확인.
3. "중범선 언제 완성하지?" → 프로젝트 페이지 → 현재 재고 입력 → 부족량 / 일퀘·주간·물교 수급처 / 다음 행동 확인.
4. "이 정보 최신 맞아?" → 모든 핵심 규칙에 출처와 마지막 검증일 표시.
5. "이 상태를 ChatGPT에 물어보고 싶어" → 현재 진행도/부족량/검증 근거를 자동 선별한 prompt를 만들어 복사.

## 권장 기술 스택

- Frontend: React + TypeScript + Vite
- Routing: React Router 또는 TanStack Router
- Backend: FastAPI + Pydantic + SQLAlchemy 2
- DB: `DATABASE_URL`로 선택. MySQL 8 권장, SQLite fallback 지원
- Styling: CSS variables + component primitives. 거대한 UI 프레임워크 의존은 피함.
- Tests: Vitest/React Testing Library + Pytest
- V1.5 AI: **외부 API 없음.** local Prompt Bridge가 ChatGPT용 Markdown context를 생성

## 로컬 실행 원칙

- 인터넷 연결 없이도 **이미 저장된 데이터와 진행도는 100% 동작**해야 한다.
- 외부 정보 갱신은 별도 "Research/Import" 흐름으로 취급한다.
- 체크리스트 초기화는 데이터 삭제가 아니라 **기간별 checklist instance** 생성으로 처리한다.

## Codex 시작

1. 현재 폴더를 Git 저장소로 만든다.
2. Codex에서 `/init`을 실행해도 되지만, 이 패키지의 `AGENTS.md`를 우선 유지한다.
3. `prompts/CODEX_BOOTSTRAP.md`의 지시를 첫 작업으로 준다.
4. 실제 Spec Kit를 쓰고 싶다면 최신 Spec Kit를 설치한 뒤 이 문서들을 specification source로 가져간다.

기존 단일 HTML 프로토타입은 `legacy-prototype/`에 보존했다. 새 앱은 이를 그대로 확장하지 말고 데이터 모델부터 재구성한다.


## V1.5 범위

V1.5까지는 비용이 발생하는 AI 연동을 하지 않는다.

- OpenAI API: 사용 안 함
- 타사 LLM API: 사용 안 함
- 로컬 LLM: 사용 안 함
- Fine-tuning: 사용 안 함
- Prompt Bridge: 사용

앱이 DB 검색, reset 계산, 완료 상태, project shortage, source verification을 처리한 뒤 사용자가 ChatGPT에 직접 붙여넣을 prompt를 생성한다. 상세 명세는 `docs/specs/002-prompt-bridge/spec.md`를 따른다.

## 현재 구현된 V1.5 vertical slice

- FastAPI + SQLAlchemy + Alembic 백엔드
- SQLite 기본 실행과 `DATABASE_URL` 기반 MySQL 전환
- content/source/evidence/schedule/checklist period instance 모델
- KST 일일, 목요일 주간 period 계산과 일요일 보상 지급 일정 분리
- 검토된 JSON seed의 멱등 import
- Dashboard, Weekly, Content Explorer, Content Detail
- 검증 상태·검증일·공식 출처 표시
- 기간별 체크 상태 저장과 과거 기록 보존
- `content_onboarding`, `weekly_review` Prompt Bridge
- Markdown 미리보기, clipboard 복사와 실패 시 수동 선택, `.md` 다운로드

프로젝트/재료 스키마가 아직 없는 이번 세로 조각에서는 `project_optimizer`를 만들지 않았다. 결정 근거는 `docs/DECISIONS.md`의 ADR-007에 기록했다.

## 실행

Python 3.12+와 Node.js 20+가 필요하다. 터미널 두 개에서 백엔드와 프런트엔드를 각각 실행한다.

### 백엔드

```powershell
cd backend
uv sync
uv run alembic upgrade head
uv run python -m app.seed
uv run uvicorn app.main:app --reload
```

API는 `http://127.0.0.1:8000`, health endpoint는 `http://127.0.0.1:8000/api/health`다. 기본 SQLite 파일은 `backend/bdo.db`에 생성된다.

### 프런트엔드

```powershell
cd frontend
npm install
npm run dev
```

브라우저에서 `http://127.0.0.1:5173`을 연다. Vite가 `/api` 요청을 로컬 FastAPI 서버로 전달한다.

## MySQL 전환

MySQL 8 데이터베이스를 먼저 만든 뒤 백엔드 터미널에서 `DATABASE_URL`을 설정한다. URL에 `%` 같은 특수 문자가 들어가면 URL encoding이 필요하다.

```powershell
$env:DATABASE_URL = "mysql+pymysql://USER:PASSWORD@127.0.0.1/bdo_companion?charset=utf8mb4"
uv run alembic upgrade head
uv run python -m app.seed
uv run uvicorn app.main:app --reload
```

앱에는 API key 설정이 없으며 Prompt Bridge는 외부 AI/LLM을 호출하지 않는다.

## 검증 명령과 결과

2026-09-02 기준 아래 검증을 통과했다.

```powershell
cd backend
uv run pytest
# 16 passed

cd ../frontend
npm run typecheck
npm run lint
npm run test
# 1 passed
npm run build
```

추가로 새 SQLite DB에 migration과 seed를 적용한 뒤 실제 서버에서 health, 7개 콘텐츠 조회, 체크 상태 저장 후 재조회, 출처 포함 Prompt Bridge 렌더링을 확인했다.
