# Data Model

## 핵심 원칙
`content`는 지식의 중심 엔티티이고, 반복/보상/프로젝트/출처는 관계 테이블로 분리한다.

## 주요 엔티티

### content
- id
- slug
- name_ko
- category
- subcategory
- summary
- purpose
- party_type
- difficulty
- recommended_ap/dp (nullable)
- status (`active`, `deprecated`, `temporarily_disabled`, `unknown`)

### content_requirement
- content_id
- kind (`quest`, `level`, `gear`, `stat`, `item`, `knowledge`, `party`, `other`)
- description
- structured_value JSON
- required/optional

### content_step
- content_id
- phase (`unlock`, `first_time`, `repeat`, `reward`)
- order_no
- title
- description
- checkable

### schedule_rule
- content_id
- rule_type (`quest_reset`, `attempt_reset`, `record_cutoff`, `reward_payout`, `spawn`, `event_end`)
- timezone (default Asia/Seoul)
- recurrence_type (`daily`, `weekly`, `rrule`, `fixed_datetime`, `manual`)
- weekday nullable (0..6)
- time_local
- rrule nullable
- effective_from / effective_to
- notes

### reward
- content_id
- name
- reward_type
- amount/min/max nullable
- is_choice
- choice_group
- recommendation nullable

### source
- id
- url
- title
- publisher
- source_type (`official_patch`, `official_guide`, `official_gm`, `official_forum`, `community`, `database`)
- published_at nullable
- retrieved_at
- region

### evidence
- entity_type / entity_id
- field_name or claim_key
- source_id
- evidence_note
- verification_status
- confidence
- last_verified_at
- superseded_by nullable

### checklist_template
- content_id nullable
- name
- recurrence_scope (`daily`, `weekly`, `custom`, `none`)
- enabled_default

### checklist_template_item
- template_id
- order_no
- label
- details
- reward_hint
- content_step_id nullable

### checklist_instance
- template_id
- period_key
- period_start / period_end
- generated_at

### checklist_item_state
- instance_id
- template_item_id
- completed
- completed_at
- note

### user_content_state
- content_id
- state (`not_started`, `foundation`, `in_progress`, `completed`, `paused`, `ignore`)
- priority
- note
- updated_at

### project / project_stage
장기 목표의 단계 DAG를 표현.

### material / project_material
- material 목표수량
- stage별 필요량
- current inventory는 user_material_inventory에 별도 저장

### character / character_role
생활 분업, 월보 부캐, 메인 등 사용자 역할.

### life_skill_profile
- skill
- state
- character_id nullable
- mastery nullable
- level_text nullable
- note

## Period key 예시
- daily KST: `D:2026-09-02`
- Thursday weekly: `W:2026-08-27T00:00+09:00`
- Sunday reward window: schedule 표시용이며 checklist period와 반드시 같지 않음.

**절대 `checked=false` 일괄 UPDATE로 초기화하지 않는다.**
