from __future__ import annotations

import json
from datetime import date, time
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import seed_dir
from app.database import SessionLocal, create_schema
from app.models import ChecklistTemplate, ChecklistTemplateItem, Content, Evidence, ScheduleRule, Source


def _read_json(path: Path) -> list[dict[str, object]]:
    return json.loads(path.read_text(encoding="utf-8"))


def import_seed(session: Session, directory: Path | None = None) -> None:
    """Idempotently import reviewed JSON seed data without inventing missing facts."""

    directory = directory or seed_dir()
    source_rows = _read_json(directory / "seed_sources.json")
    content_rows = _read_json(directory / "seed_contents.json")

    for row in source_rows:
        source = session.get(Source, row["id"])
        values = {
            "url": row["url"],
            "title": row["title"],
            "publisher": row.get("publisher"),
            "source_type": row["source_type"],
            "region": row.get("region", "KR"),
        }
        if source is None:
            session.add(Source(id=row["id"], **values))
        else:
            for key, value in values.items():
                setattr(source, key, value)
    session.flush()

    for row in content_rows:
        content = session.scalar(select(Content).where(Content.slug == row["slug"]))
        values = {
            "name_ko": row["name_ko"],
            "category": row["category"],
            "subcategory": row.get("subcategory"),
            "summary": row.get("summary"),
            "purpose": row.get("purpose"),
            "party_type": row.get("party_type"),
            "difficulty": row.get("difficulty"),
            "status": row.get("status", "active"),
            "last_verified_at": date.fromisoformat(row["last_verified_at"]),
        }
        if content is None:
            content = Content(slug=row["slug"], **values)
            session.add(content)
            session.flush()
        else:
            for key, value in values.items():
                setattr(content, key, value)

        session.query(ScheduleRule).filter(ScheduleRule.content_id == content.id).delete()
        for schedule in row.get("schedules", []):
            session.add(
                ScheduleRule(
                    content_id=content.id,
                    rule_type=schedule["rule_type"],
                    recurrence_type=schedule["recurrence_type"],
                    weekday=schedule.get("weekday"),
                    time_local=time.fromisoformat(schedule.get("time_local", "00:00")),
                    timezone=schedule.get("timezone", "Asia/Seoul"),
                    notes=schedule.get("notes"),
                )
            )

        for source_id in row.get("source_ids", []):
            evidence = session.scalar(
                select(Evidence).where(
                    Evidence.entity_type == "content",
                    Evidence.entity_id == row["slug"],
                    Evidence.claim_key == "summary",
                    Evidence.source_id == source_id,
                )
            )
            if evidence is None:
                source_note = next((s.get("notes") for s in source_rows if s["id"] == source_id), None)
                session.add(
                    Evidence(
                        entity_type="content",
                        entity_id=row["slug"],
                        claim_key="summary",
                        source_id=source_id,
                        evidence_note=source_note,
                        verification_status=row.get("verification_status", "verified"),
                        last_verified_at=date.fromisoformat(row["last_verified_at"]),
                    )
                )

        checklist = row.get("checklist")
        if checklist:
            template = session.scalar(
                select(ChecklistTemplate).where(
                    ChecklistTemplate.content_id == content.id,
                    ChecklistTemplate.name == checklist["name"],
                )
            )
            if template is None:
                template = ChecklistTemplate(
                    content_id=content.id,
                    name=checklist["name"],
                    recurrence_scope=checklist["recurrence_scope"],
                    enabled_default=True,
                )
                session.add(template)
                session.flush()
                for index, item in enumerate(checklist["items"], start=1):
                    session.add(
                        ChecklistTemplateItem(
                            template_id=template.id,
                            order_no=index,
                            label=item["label"],
                            details=item.get("details"),
                        )
                    )
    session.commit()


def main() -> None:
    create_schema()
    with SessionLocal() as session:
        import_seed(session)
    print("Seed import complete")


if __name__ == "__main__":
    main()

