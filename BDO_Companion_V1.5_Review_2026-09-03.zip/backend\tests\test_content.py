from datetime import datetime

from sqlalchemy import select

from app.content import get_content_detail, list_contents
from app.models import Evidence
from app.periods import KST


def test_source_status_and_last_verified_are_exposed(session) -> None:
    evidence = session.scalar(select(Evidence).where(Evidence.entity_id == "garmoth"))
    evidence.verification_status = "needs_review"
    session.commit()

    detail = get_content_detail(session, "garmoth", datetime(2026, 9, 2, 12, tzinfo=KST))
    assert detail is not None
    assert detail.verification_status == "needs_review"
    assert detail.sources[0].verification_status == "needs_review"
    assert detail.sources[0].last_verified_at.isoformat() == "2026-09-02"
    summary = next(item for item in list_contents(session) if item.slug == "garmoth")
    assert summary.verification_status == "needs_review"


def test_reward_payout_remains_distinct_schedule_type(session) -> None:
    detail = get_content_detail(session, "blood-altar", datetime(2026, 9, 2, 12, tzinfo=KST))
    assert detail is not None
    assert [item.rule_type for item in detail.schedules] == ["reward_payout"]


def test_superseded_source_status_is_exposed(session) -> None:
    evidence = session.scalar(select(Evidence).where(Evidence.entity_id == "garmoth"))
    evidence.verification_status = "superseded"
    session.commit()
    detail = get_content_detail(session, "garmoth", datetime(2026, 9, 2, 12, tzinfo=KST))
    assert detail is not None
    assert detail.verification_status == "superseded"
    assert detail.sources[0].verification_status == "superseded"
