from sqlalchemy import func, select

from app.models import Content, Evidence, Source
from app.seed import import_seed
from pathlib import Path


def test_seed_import_is_idempotent(session) -> None:
    counts_before = (
        session.scalar(select(func.count()).select_from(Source)),
        session.scalar(select(func.count()).select_from(Content)),
        session.scalar(select(func.count()).select_from(Evidence)),
    )
    import_seed(session, Path(__file__).resolve().parents[2] / "data")
    counts_after = (
        session.scalar(select(func.count()).select_from(Source)),
        session.scalar(select(func.count()).select_from(Content)),
        session.scalar(select(func.count()).select_from(Evidence)),
    )
    assert counts_after == counts_before

