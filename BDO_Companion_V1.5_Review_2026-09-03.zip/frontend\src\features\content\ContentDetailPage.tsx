import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { api } from '../../api'
import { StatusBadge } from '../../components/StatusBadge'
import type { ContentDetail } from '../../types'
import { PromptBridgeDialog } from '../prompt-bridge/PromptBridgeDialog'

const scheduleLabels: Record<string, string> = {
  quest_reset: '재수주 초기화', attempt_reset: '횟수 초기화', record_cutoff: '기록 집계', reward_payout: '보상 지급', spawn: '출현', event_end: '이벤트 종료',
}

export function ContentDetailPage() {
  const { slug = '' } = useParams()
  const [content, setContent] = useState<ContentDetail | null>(null)
  const [error, setError] = useState('')
  useEffect(() => { api.content(slug).then(setContent).catch((reason: Error) => setError(reason.message)) }, [slug])
  if (error) return <p className="error">{error}</p>
  if (!content) return <p className="loading">불러오는 중…</p>

  return (
    <div>
      <Link className="back-link" to="/content">← 콘텐츠 탐색</Link>
      <header className="page-header detail-header">
        <div><div className="title-badges"><span className="category">{content.category}</span><StatusBadge status={content.verification_status} /></div><h1>{content.name_ko}</h1><p className="subtitle">{content.summary}</p></div>
        <PromptBridgeDialog mode="content_onboarding" contentSlug={content.slug} />
      </header>
      <div className="detail-grid">
        <div>
          <section className="detail-section"><p className="eyebrow">OVERVIEW</p><h2>왜 하는가</h2><p>{content.purpose || '검증된 목적 설명이 아직 등록되지 않았습니다.'}</p></section>
          <section className="detail-section"><p className="eyebrow">SCHEDULES</p><h2>반복 규칙과 일정</h2>
            {content.schedules.length ? content.schedules.map((item) => (
              <article className="timeline-item" key={item.id}><span /><div><strong>{scheduleLabels[item.rule_type] ?? item.rule_type}</strong><p>{item.notes || `${item.recurrence_type} 일정`}</p><small>{item.timezone}</small></div></article>
            )) : <p className="empty">검증된 일정 정보가 없습니다.</p>}
          </section>
        </div>
        <aside className="source-panel"><p className="eyebrow">EVIDENCE</p><h2>근거와 검증 상태</h2><p className="verified-date">최종 검증일 <strong>{content.last_verified_at ?? '미확인'}</strong></p>
          {content.sources.length ? content.sources.map((source) => (
            <a href={source.url} target="_blank" rel="noreferrer" className="source-card" key={source.id}>
              <StatusBadge status={source.verification_status} /><strong>{source.title}</strong><span>{source.source_type}</span>{source.evidence_note && <p>{source.evidence_note}</p>}
            </a>
          )) : <p className="empty">연결된 출처가 없습니다.</p>}
        </aside>
      </div>
    </div>
  )
}

