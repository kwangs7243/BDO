from datetime import datetime, timedelta

from sqlalchemy import func, select

from app.checklists import get_current_checklists
from app.models import ChecklistInstance, ChecklistItemState
from app.periods import KST


def test_new_period_preserves_completed_history(session) -> None:
    first_now = datetime(2026, 9, 2, 12, 0, tzinfo=KST)
    first_instances = get_current_checklists(session, "weekly", first_now)
    first_state_id = first_instances[0].items[0].id
    state = session.get(ChecklistItemState, first_state_id)
    state.completed = True
    state.completed_at = first_now
    session.commit()

    second_instances = get_current_checklists(session, "weekly", first_now + timedelta(days=8))
    assert second_instances[0].period_key != first_instances[0].period_key
    assert second_instances[0].items[0].completed is False
    assert session.get(ChecklistItemState, first_state_id).completed is True
    assert session.scalar(select(func.count()).select_from(ChecklistInstance)) == len(first_instances) * 2
    assert second_instances[0].period_start.tzinfo is not None


def test_same_period_reuses_instance(session) -> None:
    now = datetime(2026, 9, 2, 12, 0, tzinfo=KST)
    first = get_current_checklists(session, "weekly", now)
    second = get_current_checklists(session, "weekly", now)
    assert [item.id for item in first] == [item.id for item in second]
