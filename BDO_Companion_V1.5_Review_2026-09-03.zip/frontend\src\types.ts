export type VerificationStatus = 'verified' | 'needs_review' | 'conflict' | 'superseded' | 'unverified'

export interface ContentSummary {
  slug: string
  name_ko: string
  category: string
  summary: string | null
  status: string
  last_verified_at: string | null
  verification_status: VerificationStatus
}

export interface SourceEvidence {
  id: string
  title: string
  url: string
  source_type: string
  verification_status: VerificationStatus
  last_verified_at: string
  evidence_note: string | null
}

export interface Schedule {
  id: number
  rule_type: string
  recurrence_type: string
  weekday: number | null
  time_local: string | null
  timezone: string
  notes: string | null
  next_occurrence: string | null
}

export interface ContentDetail extends ContentSummary {
  purpose: string | null
  party_type: string | null
  difficulty: string | null
  schedules: Schedule[]
  sources: SourceEvidence[]
}

export interface ChecklistItem {
  id: number
  template_item_id: number
  label: string
  details: string | null
  completed: boolean
  completed_at: string | null
  note: string | null
}

export interface ChecklistInstance {
  id: number
  template_id: number
  template_name: string
  content_slug: string | null
  period_key: string
  period_start: string
  period_end: string
  items: ChecklistItem[]
}

export interface PromptRender {
  markdown: string
  character_count: number
  estimated_tokens: number
  over_budget: boolean
}

