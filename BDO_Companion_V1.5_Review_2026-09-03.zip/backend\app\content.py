from __future__ import annotations

from datetime import datetime, time

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.models import Content, Evidence, ScheduleRule
from app.periods import next_weekly_occurrence
from app.schemas import ContentDetailOut, ContentSummaryOut, ScheduleOut, SourceOut


STATUS_PRIORITY = {"conflict": 0, "needs_review": 1, "superseded": 2, "verified": 3}


def _evidence_for(session: Session, slug: str) -> list[Evidence]:
    return list(
        session.scalars(
            select(Evidence)
            .where(Evidence.entity_type == "content", Evidence.entity_id == slug)
            .options(selectinload(Evidence.source))
            .order_by(Evidence.claim_key, Evidence.id)
        ).all()
    )


def aggregate_verification(evidence: list[Evidence]) -> str:
    if not evidence:
        return "unverified"
    return min((item.verification_status for item in evidence), key=lambda status: STATUS_PRIORITY.get(status, 0))


def list_contents(session: Session) -> list[ContentSummaryOut]:
    contents = session.scalars(select(Content).order_by(Content.name_ko, Content.slug)).all()
    return [
        ContentSummaryOut(
            slug=item.slug,
            name_ko=item.name_ko,
            category=item.category,
            summary=item.summary,
            status=item.status,
            last_verified_at=item.last_verified_at,
            verification_status=aggregate_verification(_evidence_for(session, item.slug)),
        )
        for item in contents
    ]


def _schedule_out(rule: ScheduleRule, now: datetime) -> ScheduleOut:
    next_occurrence = None
    if rule.recurrence_type == "weekly" and rule.weekday is not None:
        next_occurrence = next_weekly_occurrence(now, rule.weekday, rule.time_local or time.min)
    return ScheduleOut(
        id=rule.id,
        rule_type=rule.rule_type,
        recurrence_type=rule.recurrence_type,
        weekday=rule.weekday,
        time_local=rule.time_local.isoformat(timespec="minutes") if rule.time_local else None,
        timezone=rule.timezone,
        notes=rule.notes,
        next_occurrence=next_occurrence,
    )


def get_content_detail(session: Session, slug: str, now: datetime) -> ContentDetailOut | None:
    content = session.scalar(
        select(Content)
        .where(Content.slug == slug)
        .options(selectinload(Content.schedules))
    )
    if content is None:
        return None
    evidence = _evidence_for(session, slug)
    return ContentDetailOut(
        slug=content.slug,
        name_ko=content.name_ko,
        category=content.category,
        summary=content.summary,
        purpose=content.purpose,
        party_type=content.party_type,
        difficulty=content.difficulty,
        status=content.status,
        last_verified_at=content.last_verified_at,
        verification_status=aggregate_verification(evidence),
        schedules=[_schedule_out(rule, now) for rule in sorted(content.schedules, key=lambda row: (row.rule_type, row.id))],
        sources=[
            SourceOut(
                id=item.source.id,
                title=item.source.title,
                url=item.source.url,
                source_type=item.source.source_type,
                verification_status=item.verification_status,
                last_verified_at=item.last_verified_at,
                evidence_note=item.evidence_note,
            )
            for item in evidence
        ],
    )

