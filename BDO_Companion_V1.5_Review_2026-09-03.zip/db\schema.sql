-- Reference schema. Production should use SQLAlchemy/Alembic migrations.
CREATE TABLE source (
  id VARCHAR(64) PRIMARY KEY,
  url TEXT NOT NULL,
  title VARCHAR(255) NOT NULL,
  publisher VARCHAR(120),
  source_type VARCHAR(32) NOT NULL,
  published_at DATETIME NULL,
  retrieved_at DATETIME NULL,
  region VARCHAR(16) DEFAULT 'KR'
);

CREATE TABLE content (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  slug VARCHAR(120) UNIQUE NOT NULL,
  name_ko VARCHAR(255) NOT NULL,
  category VARCHAR(64) NOT NULL,
  subcategory VARCHAR(64),
  summary TEXT,
  purpose TEXT,
  status VARCHAR(32) DEFAULT 'active',
  last_verified_at DATETIME NULL
);

CREATE TABLE schedule_rule (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  content_id BIGINT NOT NULL,
  rule_type VARCHAR(32) NOT NULL,
  timezone VARCHAR(64) NOT NULL DEFAULT 'Asia/Seoul',
  recurrence_type VARCHAR(32) NOT NULL,
  weekday SMALLINT NULL,
  time_local TIME NULL,
  rrule TEXT NULL,
  fixed_datetime DATETIME NULL,
  effective_from DATETIME NULL,
  effective_to DATETIME NULL,
  notes TEXT,
  FOREIGN KEY (content_id) REFERENCES content(id)
);

CREATE TABLE evidence (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  entity_type VARCHAR(32) NOT NULL,
  entity_id VARCHAR(128) NOT NULL,
  claim_key VARCHAR(128) NOT NULL,
  source_id VARCHAR(64) NOT NULL,
  evidence_note TEXT,
  verification_status VARCHAR(32) NOT NULL,
  confidence DECIMAL(4,3),
  last_verified_at DATETIME NOT NULL,
  FOREIGN KEY (source_id) REFERENCES source(id)
);

CREATE TABLE checklist_template (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  content_id BIGINT NULL,
  name VARCHAR(255) NOT NULL,
  recurrence_scope VARCHAR(32) NOT NULL,
  enabled_default BOOLEAN NOT NULL DEFAULT TRUE,
  FOREIGN KEY (content_id) REFERENCES content(id)
);

CREATE TABLE checklist_template_item (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  template_id BIGINT NOT NULL,
  order_no INT NOT NULL,
  label VARCHAR(255) NOT NULL,
  details TEXT,
  reward_hint TEXT,
  FOREIGN KEY (template_id) REFERENCES checklist_template(id)
);

CREATE TABLE checklist_instance (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  template_id BIGINT NOT NULL,
  period_key VARCHAR(100) NOT NULL,
  period_start DATETIME NOT NULL,
  period_end DATETIME NOT NULL,
  generated_at DATETIME NOT NULL,
  UNIQUE(template_id, period_key),
  FOREIGN KEY (template_id) REFERENCES checklist_template(id)
);

CREATE TABLE checklist_item_state (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  instance_id BIGINT NOT NULL,
  template_item_id BIGINT NOT NULL,
  completed BOOLEAN NOT NULL DEFAULT FALSE,
  completed_at DATETIME NULL,
  note TEXT,
  UNIQUE(instance_id, template_item_id),
  FOREIGN KEY (instance_id) REFERENCES checklist_instance(id),
  FOREIGN KEY (template_item_id) REFERENCES checklist_template_item(id)
);
