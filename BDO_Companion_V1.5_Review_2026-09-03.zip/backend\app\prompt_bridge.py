from __future__ import annotations

from datetime import datetime

from sqlalchemy.orm import Session

from app.checklists import get_current_checklists
from app.content import get_content_detail
from app.schemas import (
    PromptChecklistItem,
    PromptContextBundle,
    PromptFact,
    PromptMode,
    PromptRenderOut,
    PromptRequest,
)


PRESET_GOALS = {
    PromptMode.CONTENT_ONBOARDING: "이 콘텐츠를 처음 시작하는 사용자가 진입 순서와 반복 루틴을 이해하도록 설명해 주세요.",
    PromptMode.WEEKLY_REVIEW: "남은 주간 항목을 마감과 가치 기준으로 우선순위화해 주세요.",
}

GUARDRAILS = (
    "제공된 verified 데이터를 우선 사용하세요.",
    "날짜나 패치에 따라 달라지는 정보는 최신 KR 공식 자료를 우선 확인하세요.",
    "미검증 값은 추측하지 마세요.",
    "과거 공략과 최신 공식 자료가 충돌하면 최신 공식 자료를 우선하세요.",
    "정확한 수량, 초기화, 보상은 근거 없이 단정하지 마세요.",
    "이미 완료한 항목을 다시 해야 할 일로 추천하지 마세요.",
)


def build_context(session: Session, request: PromptRequest, now: datetime) -> PromptContextBundle:
    facts: list[PromptFact] = []
    unresolved: list[PromptFact] = []
    schedules: list[str] = []
    sources = []
    checklist: list[PromptChecklistItem] = []
    request_context = {"mode": request.mode.value, "page": "weekly"}

    if request.mode == PromptMode.CONTENT_ONBOARDING:
        if not request.content_slug:
            raise ValueError("content_slug is required for content_onboarding")
        detail = get_content_detail(session, request.content_slug, now)
        if detail is None:
            raise LookupError(request.content_slug)
        request_context["page"] = f"content/{detail.slug}"
        sources = detail.sources
        if detail.summary:
            primary = detail.sources[0] if detail.sources else None
            fact = PromptFact(
                claim=detail.summary,
                verification_status=detail.verification_status,
                last_verified_at=detail.last_verified_at,
                source_title=primary.title if primary else None,
                source_url=primary.url if primary else None,
                source_type=primary.source_type if primary else None,
            )
            (facts if fact.verification_status == "verified" else unresolved).append(fact)
        schedules = [
            f"{item.rule_type}: {item.notes or item.recurrence_type} ({item.timezone})"
            for item in detail.schedules
        ]
        for scope in ("daily", "weekly"):
            for instance in get_current_checklists(session, scope, now):
                if instance.content_slug == detail.slug:
                    checklist.extend(
                        PromptChecklistItem(label=item.label, completed=item.completed, period_key=instance.period_key)
                        for item in instance.items
                    )
    else:
        for instance in get_current_checklists(session, "weekly", now):
            checklist.extend(
                PromptChecklistItem(label=item.label, completed=item.completed, period_key=instance.period_key)
                for item in instance.items
            )
        schedules.append("일반 주간 체크리스트 기간은 목요일 00:00 KST 경계로 계산됨")

    facts.sort(key=lambda item: (item.claim, item.source_url or ""))
    unresolved.sort(key=lambda item: (item.verification_status, item.claim))
    sources = sorted(sources, key=lambda item: (item.source_type, item.title, item.id))
    checklist.sort(key=lambda item: (item.period_key, item.label))
    return PromptContextBundle(
        generated_at=now,
        request_context=request_context,
        canonical_facts=facts,
        schedules=schedules,
        checklist=checklist,
        open_questions_or_conflicts=unresolved,
        sources=sources,
        user_question=request.user_question.strip(),
    )


def _fact_lines(facts: list[PromptFact]) -> list[str]:
    lines: list[str] = []
    for fact in facts:
        lines.append(f"- {fact.claim}")
        lines.append(f"  - verification: {fact.verification_status}")
        if fact.last_verified_at:
            lines.append(f"  - last_verified: {fact.last_verified_at.isoformat()}")
        if fact.source_title:
            lines.append(f"  - source: {fact.source_title} ({fact.source_type})")
        if fact.source_url:
            lines.append(f"  - url: {fact.source_url}")
    return lines or ["- none"]


def render_markdown(bundle: PromptContextBundle) -> str:
    mode = PromptMode(bundle.request_context["mode"])
    lines = [
        "# BDO Companion Context",
        f"Generated: {bundle.generated_at.isoformat()}",
        f"Region: {bundle.region}",
        "",
        "## REQUEST_CONTEXT",
        f"- page: {bundle.request_context['page']}",
        f"- mode: {mode.value}",
        f"- goal: {PRESET_GOALS[mode]}",
        "",
        "## RESPONSE_GUARDRAILS",
        *[f"- {item}" for item in GUARDRAILS],
        "",
        "## USER_STATE",
        *(f"- {item}" for item in bundle.user_state),
    ]
    if not bundle.user_state:
        lines.append("- 저장된 사용자 상태 없음")
    lines.extend(["", "## CANONICAL_FACTS", *_fact_lines(bundle.canonical_facts)])
    lines.extend(["", "## SCHEDULES", *(f"- {item}" for item in bundle.schedules)])
    if not bundle.schedules:
        lines.append("- none")
    lines.extend(["", "## CHECKLIST_STATE"])
    if bundle.checklist:
        lines.extend(
            f"- [{'x' if item.completed else ' '}] {item.label} ({item.period_key})" for item in bundle.checklist
        )
    else:
        lines.append("- none")
    if bundle.project_state:
        lines.extend(["", "## PROJECT_STATE", *(f"- {item}" for item in bundle.project_state)])
    lines.extend(["", "## OPEN_QUESTIONS_OR_CONFLICTS", *_fact_lines(bundle.open_questions_or_conflicts)])
    lines.extend(["", "## SOURCES"])
    if bundle.sources:
        lines.extend(
            f"{index}. [{item.title}]({item.url}) — {item.source_type}, {item.verification_status}, verified {item.last_verified_at.isoformat()}"
            for index, item in enumerate(bundle.sources, start=1)
        )
    else:
        lines.append("- none")
    lines.extend(["", "## USER_QUESTION", bundle.user_question or "제공된 컨텍스트를 바탕으로 목적에 맞게 답해 주세요."])
    return "\n".join(lines).strip() + "\n"


def render_result(bundle: PromptContextBundle) -> PromptRenderOut:
    markdown = render_markdown(bundle)
    characters = len(markdown)
    estimated_tokens = (characters + 3) // 4
    return PromptRenderOut(
        bundle=bundle,
        markdown=markdown,
        character_count=characters,
        estimated_tokens=estimated_tokens,
        over_budget=estimated_tokens > 12_000,
    )
