"""Create V1.5 vertical-slice tables."""

from alembic import op
import sqlalchemy as sa


revision = "20260902_0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Keep the migration dialect-independent; SQLite and MySQL both support these types.
    from app.database import Base
    from app import models  # noqa: F401

    Base.metadata.create_all(op.get_bind())


def downgrade() -> None:
    from app.database import Base
    from app import models  # noqa: F401

    Base.metadata.drop_all(op.get_bind())

